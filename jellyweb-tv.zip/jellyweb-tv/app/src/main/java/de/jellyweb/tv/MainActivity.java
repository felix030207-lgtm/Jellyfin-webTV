package de.jellyweb.tv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.content.pm.ApplicationInfo;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.text.InputType;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.URL;

/**
 * JellyWeb TV: oeffnet die normale Jellyfin-Weboberflaeche des eigenen Servers
 * im Vollbild. Dadurch funktionieren Web-Plugins wie Bonfire (Profilauswahl)
 * und Media Bar Enhanced genauso wie im Browser.
 *
 * Bedienung mit der Fernbedienung:
 *   Pfeiltasten / OK  -> navigieren und auswaehlen
 *   Zurueck           -> eine Seite zurueck (auf der Startseite: 2x druecken zum Beenden)
 *   Menue-Taste oder Zurueck lange gedrueckt -> kleines Menue (Server aendern usw.)
 */
public class MainActivity extends Activity {

    private static final String PREFS = "jellyweb";
    private static final String KEY_URL = "server_url";
    private static final String KEY_TV = "tv_mode";
    private static final int MATCH = FrameLayout.LayoutParams.MATCH_PARENT;

    private FrameLayout root;
    private WebView webView;
    private TextView status;
    private WebChromeClient chromeClient;
    private WebChromeClient.CustomViewCallback customCallback;
    private View customView;
    private AlertDialog dialog;

    private String defaultUserAgent;
    private String serverUrl;
    private boolean tvMode;
    private boolean pageError;
    private boolean longBackHandled;
    private long lastBackPress;

    // ------------------------------------------------------------------
    // Start
    // ------------------------------------------------------------------

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        serverUrl = prefs.getString(KEY_URL, null);
        tvMode = prefs.getBoolean(KEY_TV, true);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.BLACK);
        root.addView(webView, new FrameLayout.LayoutParams(MATCH, MATCH));

        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(26);
        status.setGravity(Gravity.CENTER);
        status.setBackgroundColor(Color.BLACK);
        status.setPadding(80, 40, 80, 40);
        root.addView(status, new FrameLayout.LayoutParams(MATCH, MATCH));

        setContentView(root);
        hideSystemUi();
        configureWebView();

        if (serverUrl == null) {
            startFirstSetup();
        } else {
            openServer();
        }
    }

    @SuppressWarnings("deprecation")
    private void configureWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        defaultUserAgent = s.getUserAgentString();
        applyUserAgent();

        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(webView, true);

        if ((getApplicationInfo().flags & ApplicationInfo.FLAG_DEBUGGABLE) != 0) {
            WebView.setWebContentsDebuggingEnabled(true);
        }

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                pageError = false;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                CookieManager.getInstance().flush();
                if (!pageError) {
                    status.setVisibility(View.GONE);
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request,
                                        WebResourceError error) {
                if (request.isForMainFrame()) {
                    showLoadError();
                }
            }

            @Override
            public void onReceivedError(WebView view, int errorCode, String description,
                                        String failingUrl) {
                // Nur fuer alte Android-Versionen (< 6); neuere nutzen die Methode oben.
                if (Build.VERSION.SDK_INT < 23) {
                    showLoadError();
                }
            }
        });

        chromeClient = new WebChromeClient() {
            @Override
            public void onShowCustomView(View view, CustomViewCallback callback) {
                if (customView != null) {
                    callback.onCustomViewHidden();
                    return;
                }
                customView = view;
                customCallback = callback;
                webView.setVisibility(View.GONE);
                root.addView(view, new FrameLayout.LayoutParams(MATCH, MATCH));
            }

            @Override
            public void onHideCustomView() {
                if (customView == null) {
                    return;
                }
                root.removeView(customView);
                customView = null;
                webView.setVisibility(View.VISIBLE);
                webView.requestFocus();
                if (customCallback != null) {
                    customCallback.onCustomViewHidden();
                    customCallback = null;
                }
            }
        };
        webView.setWebChromeClient(chromeClient);
        webView.requestFocus();
    }

    /** TV-Ansicht: "Mobile" aus dem User-Agent entfernen und "Android TV" anhaengen,
     *  damit Jellyfin die grosse Fernseher-Oberflaeche waehlt. */
    private void applyUserAgent() {
        String ua = defaultUserAgent;
        if (tvMode) {
            ua = ua.replace(" Mobile", "") + " Android TV";
        }
        webView.getSettings().setUserAgentString(ua);
    }

    private void openServer() {
        pageError = false;
        status.setText("Verbinde mit Jellyfin …");
        status.setVisibility(View.VISIBLE);
        webView.loadUrl(serverUrl);
    }

    private void showLoadError() {
        pageError = true;
        status.setText("Server nicht erreichbar:\n" + serverUrl
                + "\n\nIst der Fernseher im Netzwerk und Jellyfin gestartet?");
        status.setVisibility(View.VISIBLE);
        showMenu(true);
    }

    // ------------------------------------------------------------------
    // Server-Adresse: automatische Suche + Eingabe
    // ------------------------------------------------------------------

    private void startFirstSetup() {
        status.setText("Suche Jellyfin-Server im Heimnetz …");
        status.setVisibility(View.VISIBLE);
        new Thread(() -> {
            final String found = discoverServer();
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) {
                    return;
                }
                status.setText("JellyWeb TV");
                showUrlDialog(found);
            });
        }).start();
    }

    /** Jellyfin antwortet im lokalen Netz auf UDP-Port 7359. Klappt nicht bei jedem
     *  Docker-Setup - dann bleibt einfach die manuelle Eingabe. */
    private String discoverServer() {
        DatagramSocket socket = null;
        try {
            socket = new DatagramSocket();
            socket.setBroadcast(true);
            socket.setSoTimeout(3000);
            byte[] msg = "who is JellyfinServer?".getBytes("UTF-8");
            socket.send(new DatagramPacket(msg, msg.length,
                    InetAddress.getByName("255.255.255.255"), 7359));
            DatagramPacket reply = new DatagramPacket(new byte[2048], 2048);
            socket.receive(reply);
            String json = new String(reply.getData(), 0, reply.getLength(), "UTF-8");
            String address = new JSONObject(json).optString("Address", "");
            int port = 8096;
            if (!address.isEmpty()) {
                int p = new URL(address).getPort();
                if (p > 0) {
                    port = p;
                }
            }
            // Absender-Adresse nehmen: die stimmt auch, wenn der Server hinter Docker sitzt.
            return "http://" + reply.getAddress().getHostAddress() + ":" + port;
        } catch (Exception e) {
            return null;
        } finally {
            if (socket != null) {
                socket.close();
            }
        }
    }

    private void showUrlDialog(String suggestion) {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        input.setSingleLine(true);
        String prefill = suggestion != null ? suggestion
                : (serverUrl != null ? serverUrl : "http://");
        input.setText(prefill);
        input.setSelection(prefill.length());

        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle("Jellyfin-Server")
                .setMessage(suggestion != null
                        ? "Server im Heimnetz gefunden. Mit OK bestätigen oder die Adresse ändern."
                        : "Adresse deines Jellyfin-Servers eingeben,\nz. B. http://192.168.178.50:8096")
                .setView(input)
                .setPositiveButton("OK", (d, which) -> saveUrl(input.getText().toString()));
        if (serverUrl == null) {
            b.setCancelable(false);
            b.setNegativeButton("Beenden", (d, which) -> finish());
        } else {
            b.setNegativeButton("Abbrechen", null);
        }
        dialog = b.create();
        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
        dialog.show();
    }

    private void saveUrl(String raw) {
        String u = raw == null ? "" : raw.trim();
        if (u.isEmpty() || u.equals("http://") || u.equals("https://")) {
            Toast.makeText(this, "Bitte eine Adresse eingeben", Toast.LENGTH_SHORT).show();
            showUrlDialog(null);
            return;
        }
        if (!u.startsWith("http://") && !u.startsWith("https://")) {
            u = "http://" + u;
        }
        while (u.endsWith("/")) {
            u = u.substring(0, u.length() - 1);
        }
        serverUrl = u;
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_URL, u).apply();
        openServer();
    }

    // ------------------------------------------------------------------
    // Menue
    // ------------------------------------------------------------------

    private void showMenu(boolean afterError) {
        if (dialog != null && dialog.isShowing()) {
            return;
        }
        final String[] items = {
                "Neu laden",
                "Server-Adresse ändern",
                "TV-Ansicht: " + (tvMode ? "an" : "aus") + " (umschalten)",
                "Zwischenspeicher leeren und neu laden",
                "App beenden"
        };
        dialog = new AlertDialog.Builder(this)
                .setTitle(afterError ? "Verbindung fehlgeschlagen" : "Menü")
                .setItems(items, (d, which) -> {
                    switch (which) {
                        case 0:
                            if (serverUrl != null) {
                                openServer();
                            }
                            break;
                        case 1:
                            showUrlDialog(null);
                            break;
                        case 2:
                            tvMode = !tvMode;
                            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                                    .putBoolean(KEY_TV, tvMode).apply();
                            applyUserAgent();
                            if (serverUrl != null) {
                                openServer();
                            }
                            break;
                        case 3:
                            webView.clearCache(true);
                            if (serverUrl != null) {
                                openServer();
                            }
                            break;
                        default:
                            finish();
                            break;
                    }
                })
                .create();
        dialog.show();
    }

    // ------------------------------------------------------------------
    // Fernbedienung
    // ------------------------------------------------------------------

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            longBackHandled = false;
            event.startTracking();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    public boolean onKeyLongPress(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            longBackHandled = true;
            showMenu(false);
            return true;
        }
        return super.onKeyLongPress(keyCode, event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (!longBackHandled && event.isTracking() && !event.isCanceled()) {
                handleBack();
            }
            longBackHandled = false;
            return true;
        }
        if (keyCode == KeyEvent.KEYCODE_MENU || keyCode == KeyEvent.KEYCODE_SETTINGS) {
            showMenu(false);
            return true;
        }
        return super.onKeyUp(keyCode, event);
    }

    private void handleBack() {
        if (customView != null) {
            chromeClient.onHideCustomView();
            return;
        }
        String url = webView.getUrl();
        boolean atHome = url != null && (url.endsWith("#/home") || url.endsWith("#/home.html"));
        if (!atHome && webView.canGoBack()) {
            webView.goBack();
            return;
        }
        long now = SystemClock.elapsedRealtime();
        if (now - lastBackPress < 2500) {
            finish();
        } else {
            lastBackPress = now;
            Toast.makeText(this, "Zum Beenden nochmal Zurück drücken", Toast.LENGTH_SHORT).show();
        }
    }

    // ------------------------------------------------------------------
    // Lebenszyklus / Vollbild
    // ------------------------------------------------------------------

    @SuppressWarnings("deprecation")
    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            hideSystemUi();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        webView.onResume();
    }

    @Override
    protected void onPause() {
        CookieManager.getInstance().flush();
        webView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (dialog != null && dialog.isShowing()) {
            dialog.dismiss();
        }
        root.removeAllViews();
        webView.destroy();
        super.onDestroy();
    }
}
